import json
import os
from requests import RequestException
from multiacq.gw_helper import GwCfg, GwHeaderException, GwTokenException, GwResponseException, GwSelectionException
from multiacq.gw_init import Gwinit
from multiacq.gw_card import GatewayByCard, GatewayByPaymentLink
from multiacq.gw_tracknumb import GwByTrackingNumber
from typing import Tuple, List, Dict, Any

GW_POSTILION_URL = os.getenv("GW_POSTILION_URL", "http://unknown")

GW_POSTILION_MANDATORY = ("1" == os.getenv("GW_POSTILION_MANDATORY", "0"))

GW_GLOBAL_URL = os.getenv("GW_GLOBAL_URL", "http://unknown")

GW_GLOBAL_MANDATORY = ("1" == os.getenv("GW_GLOBAL_MANDATORY", "0"))

CARDBRAND_URL = os.getenv("CARDBRAND_URL", "http://unknown")

gateways: Dict[str, GwCfg] = {
    "001": GwCfg(GW_POSTILION_URL, ['visa', 'elo'], 20, GW_POSTILION_MANDATORY),
    "002": GwCfg(GW_GLOBAL_URL, None, 1, GW_GLOBAL_MANDATORY)
}

common_headers: Dict[str, str] = {
    "Access-Control-Allow-Origin": "*",
    "Vary": "Origin"
}

options_headers: Dict[str, str] = {
    **common_headers,
    "Access-Control-Allow-Headers": "content-type, paymentlinkslug, accept, authorization, x-customer",
    "Access-Control-Allow-Methods": "OPTIONS, POST"
}

post_headers: Dict[str, str] = {
    **common_headers,
    "Content-Type": "application/json"}


def load_allowed() -> Tuple[List[str], List[str]]:
    allowed_customers: List[str] = []
    allowed_merchants: List[str] = []
    allowed_file_path = os.path.join(os.path.dirname(
        os.path.realpath(__file__)), "allowed.json")

    try:
        with open(allowed_file_path) as allowed_file:
            allowed: Dict[str, List[str]] = json.load(allowed_file)
            allowed_customers.extend(allowed.get("customers", []))
            allowed_merchants.extend(allowed.get("merchants", []))
    except Exception as e:
        print(f"Unable to read {allowed_file_path}")
        print(e)

    return allowed_customers, allowed_merchants


allowed_customers, allowed_merchants = load_allowed()


def response_failure(status_code: int, lambda_msg: str, msg: str, e: Exception):
    if e is not None:
        print(f'{msg}: {e}')

    failure_msg: Dict[str, Any] = {
        "errors": [
            {
                "msg": f"Lambda error, please {lambda_msg}",
                "code": "MSG_LAMBDA_ERROR",
                "exception": msg
            }
        ],

        "token": "Unknown"
    }

    return {"statusCode": status_code, "headers": post_headers, "body": json.dumps(failure_msg)}


def response_failure_bad_request(msg: str, e: Exception = None):
    return response_failure(400, "verify request", msg, e)


def response_failure_server_error(msg: str, e: Exception):
    return response_failure(500, "contact HelpDesk", msg, e)


def response_options():
    return {"statusCode": 200, "headers": options_headers}


def lambda_handler(event, context):
    try:
        http_method = event['httpMethod']

        if http_method == "OPTIONS":
            return response_options()
        if http_method == "POST":
            status_code: int = -1
            body: str = ""
            endpoint: str = str(event['path']).split("/")[-1]

            if "initialization" == endpoint:
                status_code, body = Gwinit(gateways, event).response()
            elif endpoint in ['void', 'capture']:
                status_code, body = GwByTrackingNumber(
                    gateways, event).response()
            elif endpoint in ['sale', 'pre-authorization']:
                status_code, body = GatewayByCard(
                    CARDBRAND_URL, gateways, event).response()
            elif endpoint in ['authorization']:
                status_code, body = GatewayByPaymentLink(
                    CARDBRAND_URL, gateways, event, allowed_customers, allowed_merchants).response()
            else:
                return response_failure_bad_request("Invalid endpoint")

            return {"statusCode": status_code, "headers": post_headers, "body": body}
        else:
            return response_failure_bad_request("Invalid method")
    except KeyError as e:
        return response_failure_bad_request("Request key field is missing", e)
    except GwHeaderException as e:
        return response_failure_bad_request("HTTP header is missing", e)
    except GwTokenException as e:
        return response_failure_server_error("Token failure", e)
    except GwResponseException as e:
        return response_failure_server_error("Gateway response failure", e)
    except GwSelectionException as e:
        return response_failure_server_error("Gateway selection failure", e)
    except RequestException as e:
        return response_failure_server_error("Request forward failure", e)
    except Exception as e:
        return response_failure_server_error("Other server failure", e)
