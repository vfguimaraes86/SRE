import json
import requests
from time import time
from base64 import b64decode
from typing import Tuple, Dict, Any, List
from abc import ABC, abstractmethod
from enum import Enum

__all__ = ['GwCfg',
           'GwAuthHeader',
           'GwHeaderException',
           'GwTokenException',
           'GwResponseException',
           'GwSelectionException',
           'GwHelper',
           'GwTransactionHelper']


class GwCfg(object):
    def __init__(self, url: str, cardbrands: List[str], tracking_number_len: int, mandatory: bool = False):
        self.url: str = url
        self.cardbrands: List[str] = cardbrands
        self.tracking_number_len: int = tracking_number_len
        self.mandatory: bool = mandatory

    def check_cardbrand(self, cardbrand: str) -> bool:
        return self.cardbrands is None or cardbrand in self.cardbrands

    def check_tracking_number_len(self, tracking_number_len: int) -> bool:
        return tracking_number_len >= self.tracking_number_len


class GwAuthHeader(Enum):
    AUTHORIZATION = 1
    PAYMENTSLUG = 2


class GwHeaderException(Exception):
    """HTTP header missing"""


class GwTokenException(Exception):
    """Gateway token failure"""


class GwResponseException(Exception):
    """Gateway responsefailure"""


class GwSelectionException(Exception):
    """Gateway selection failure"""


class GwHelper(ABC):
    headers_name: List[str] = ["User-Agent",
                               "Cache-Control",
                               "Content-Type",
                               "X-Forwarded-For",
                               "X-Forwarded-Port",
                               "X-Forwarded-Proto"]

    auth_headers_config: Dict[GwAuthHeader, Tuple[str, bool]] = {
        GwAuthHeader.AUTHORIZATION: ("Authorization",  True),
        GwAuthHeader.PAYMENTSLUG: ("paymentLinkSlug", False)
    }

    def __init_headers(self, event_headers: Dict[str, Any], auth_header: GwAuthHeader) -> Tuple[Dict[str, Any], str, bool]:
        auth_header, auth_header_combined = self.auth_headers_config[auth_header]
        headers: Dict[str, str] = {}

        event_headers_lower = {k.lower(): v for k, v in event_headers.items()}

        for header_name in (self.headers_name + [auth_header]):
            if header_name.lower() in event_headers_lower:
                headers[header_name] = event_headers_lower[header_name.lower()]

        if auth_header not in headers:
            raise GwHeaderException(auth_header)

        headers["Accept"] = "application/json"

        return headers, auth_header, auth_header_combined

    def __init_body_key(self):
        version, endpoint_sub = str(self.path).split("/")[1:3]
        return version == "v1" and endpoint_sub != "virtual"

    def __init__(self, gateways: Dict[str, GwCfg], event: Dict[str, Any], auth_header: GwAuthHeader):
        self.gateways: Dict[str, GwCfg] = gateways
        self.gateway_keys: List[str] = list(gateways.keys())
        self.path: str = event["path"]
        self.body: bytes = b64decode(event["body"])
        self.body_key: bool = self.__init_body_key()
        self.headers, self.auth_header, self.auth_header_combined = self.__init_headers(
            event["headers"], auth_header)

    def parse_body(self, body: bytes) -> Tuple[str, Dict[str, Any]]:
        jbody: Dict[str, str] = json.loads(body)

        body_key: str = None

        if self.body_key:
            body_key = next(iter(jbody.keys()))
            jbody = jbody[body_key]

        return body_key, jbody


class GwTransactionHelper(GwHelper):
    TIMEOUT = (5, 30)

    def __init_tokens(self):
        if self.auth_header_combined:
            try:
                self.authorizations: Dict[str, Any] = json.loads(
                    b64decode(self.headers[self.auth_header]).decode())
                self.authorization_keys: List[str] = self.authorizations.keys()
            except Exception:
                raise GwTokenException("Cannot parse authorization tokens")

    def __init__(self, gateways: Dict[str, GwCfg], event: Dict[str, Any], auth_header: GwAuthHeader):
        super().__init__(gateways, event, auth_header)
        self.authorizations: Dict[str, Any] = {}
        self.authorization_keys: List[str] = []
        self.__init_tokens()
        self.jbody: Dict[str, Any] = self.parse_body(self.body)[1]

    @abstractmethod
    def gateway_setup(self) -> Tuple[str, str]:
        pass

    def __gateway_setup(self) -> Tuple[str, str]:
        gateway_key, gateway_url = self.gateway_setup()

        if self.auth_header_combined:
            self.headers[self.auth_header] = self.authorizations[gateway_key]

        return gateway_key, gateway_url

    def __response_content(self, content: bytes, gateway_key: str) -> str:
        jbody: Dict[str, str] = json.loads(content)

        if self.body_key and "errors" not in jbody:
            jbody[next(iter(jbody.keys()))]['multiacqId'] = gateway_key
        else:
            jbody['multiacqId'] = gateway_key

        return json.dumps(jbody)

    def response(self) -> Tuple[int, str]:
        start_time = time()

        gateway_key, gateway_url = self.__gateway_setup()

        gateway_setup_time: str = '{:.2f}'.format(time() - start_time)

        start_time = time()

        http_response = requests.post(
            url=f'{gateway_url}{self.path}',
            data=self.body,
            headers=self.headers,
            timeout=GwTransactionHelper.TIMEOUT
        )

        content = self.__response_content(http_response.content, gateway_key)

        transaction_time: str = '{:.2f}'.format(time() - start_time)

        print(f"[{gateway_key}] Gateway setup: {gateway_setup_time} seconds, Transaction: {transaction_time} seconds")

        return http_response.status_code, content
