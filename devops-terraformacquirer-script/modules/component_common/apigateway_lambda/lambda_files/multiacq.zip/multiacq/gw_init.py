import json
import requests
from concurrent.futures import ThreadPoolExecutor
from base64 import b64encode
from typing import Tuple, Dict, Any
from multiacq.gw_helper import GwCfg, GwAuthHeader, GwResponseException, GwHelper

__all__ = ['Gwinit']


class Gwinit(GwHelper):
    timeout = (5, 15)

    def __init__(self, gateways: Dict[str, GwCfg], event: Dict[str, Any]):
        super().__init__(gateways, event, GwAuthHeader.AUTHORIZATION)

    def __do_requests(self) -> Dict[str, Tuple[int, str, bool]]:
        gw_responses: Dict[str, Tuple[int, str, bool]] = {}

        with ThreadPoolExecutor(max_workers=len(self.gateway_keys)) as executor:
            futures = []

            for key in self.gateway_keys:
                gw_cfg: GwCfg = self.gateways[key]

                future = executor.submit(
                    requests.post,
                    url=f'{gw_cfg.url}{self.path}',
                    data=self.body,
                    headers=self.headers,
                    timeout=self.timeout
                )

                futures.append((key, future))

            for key, future in futures:
                http_response = future.result()
                gw_responses[key] = (http_response.status_code,
                                     http_response.content.decode(),
                                     gw_cfg.mandatory)

        return gw_responses

    def response_body(self, gw_key: str, gw_body: Dict[str, str], response: Dict[str, str], transactionalToken: Dict[str, str]) -> None:
        for body_key in gw_body.keys():
            if body_key == "transactionalToken":
                transactionalToken[gw_key] = gw_body[body_key]
                response[body_key] = None
            elif body_key not in response:
                response[body_key] = gw_body[body_key]

    def response(self) -> Tuple[int, Dict[str, str], str]:
        gw_responses: Dict[str, Tuple[int, str]] = self.__do_requests()
        gw_body_key: str = None
        response: Dict[str, str] = {}
        transactionalToken: Dict[str, str] = {}

        for gw_key in gw_responses.keys():
            status_code, content, mandatory = gw_responses[gw_key]

            try:
                gw_body_key, gw_body = self.parse_body(content)

                if 200 == status_code and "code" in gw_body and "transactionalToken" in gw_body:
                    self.response_body(
                        gw_key, gw_body, response, transactionalToken)
                elif mandatory:
                    return status_code, content
            except json.JSONDecodeError:
                raise GwResponseException(content)

        if len(transactionalToken.keys()) > 0:
            response["transactionalToken"] = b64encode(
                json.dumps(transactionalToken).encode()).decode()

            if gw_body_key:
                return 200, json.dumps({gw_body_key: response})
            else:
                return 200, json.dumps(response)
        else:
            return gw_responses[gw_key][0:2]
