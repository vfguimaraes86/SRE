from typing import Tuple, Dict, Any
from multiacq.gw_helper import GwCfg, GwAuthHeader, GwSelectionException, GwTransactionHelper

__all__ = ['GwByTrackingNumber']


class GwByTrackingNumber(GwTransactionHelper):
    def __init__(self, gateways: Dict[str, GwCfg], event: Dict[str, Any]):
        super().__init__(gateways, event, GwAuthHeader.AUTHORIZATION)

    def gateway_setup(self) -> Tuple[str, str]:
        trackingNumberLen: int = len(self.jbody['trackingNumber'])

        for key in self.authorization_keys:
            gw_cfg = self.gateways[key]

            if gw_cfg.check_tracking_number_len(trackingNumberLen):
                return key, gw_cfg.url

        raise GwSelectionException("Tracking number")
