import json
import requests
from typing import Tuple, List, Dict, Any
from multiacq.gw_helper import GwCfg, GwAuthHeader, GwSelectionException, GwTransactionHelper


__all__ = ['GatewayByCard', 'GatewayByPaymentLink']


class GwCardBrandHelper(GwTransactionHelper):
    TIMEOUT = (5, 5)

    def __init__(self, cardbrand_url: str, gateways: Dict[str, GwCfg], event: Dict[str, Any], auth_header: GwAuthHeader):
        super().__init__(gateways, event, auth_header)
        self.cardbrand_url: str = cardbrand_url
        self.gateway_setup_keys: List[str] = []

    def gateway_setup(self) -> Tuple[str, str]:
        bin = self.jbody["cardNumber"][:6]
        type = self.jbody.get("type", "CREDIT")
        cardbrand: str = "master"
        http_response = requests.get(
            url=f'{self.cardbrand_url}/{bin}/{type}', timeout=GwCardBrandHelper.TIMEOUT)

        if http_response.status_code == 200:
            response_body: Dict[str, Any] = json.loads(http_response.content)
            cardbrand = str(response_body.get("name", cardbrand)).lower()

        for key in self.gateway_setup_keys:
            gw_cfg = self.gateways[key]

            if gw_cfg.check_cardbrand(cardbrand):
                return key, gw_cfg.url

        raise GwSelectionException("Cardbrand")


class GatewayByCard(GwCardBrandHelper):
    def __init__(self, cardbrand_url: str, gateways: Dict[str, Any], event: Dict[str, Any]):
        super().__init__(cardbrand_url, gateways, event, GwAuthHeader.AUTHORIZATION)
        self.gateway_setup_keys = self.authorization_keys


class GatewayByPaymentLink(GwCardBrandHelper):
    def __init__(self, cardbrand_url: str, gateways: Dict[str, Any], event: Dict[str, Any], allowed_customers: List[str], allowed_merchants: List[str]):
        super().__init__(cardbrand_url, gateways, event, GwAuthHeader.PAYMENTSLUG)
        self.gateway_setup_keys = self.gateway_keys
        self.allowed_customers = allowed_customers
        self.allowed_merchants = allowed_merchants

    def gateway_setup(self) -> Tuple[str, str]:
        try:
            if (len(self.allowed_customers) > 0 or len(self.allowed_merchants) > 0) and \
                self.jbody["customerSlug"] not in self.allowed_customers and \
                    self.jbody["merchantSlug"] not in self.allowed_merchants:
                key: str = "002"
                gw_cfg: GwCfg = self.gateways[key]
                return key, gw_cfg.url
        except KeyError:
            pass

        return super().gateway_setup()
