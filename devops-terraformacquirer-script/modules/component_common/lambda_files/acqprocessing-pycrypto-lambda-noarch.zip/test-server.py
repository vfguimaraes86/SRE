from flask import Flask, request, make_response
from flask_restful import Resource, Api
from lambda_function import lambda_handler

app = Flask(__name__)
api = Api(app)


def send_response(response: dict):
    body: str = "Invalid request"
    status_code: int = 400
    headers: dict = {
        "Content-Type": "text/plain"
    }

    if "body" in response:
        body = response["body"]

    if "statusCode" in response:
        status_code = response["statusCode"]

    if "headers" in response:
        headers = {
            "Content-Type": "application/json"
        }

    return make_response(body, status_code, headers)


class Lambda(Resource):

    @staticmethod
    def get():
        event = {"httpMethod": "GET",
                 "path": request.path}

        response: dict = lambda_handler(event=event, context=None)

        return send_response(response)

    @staticmethod
    def post():
        user_input = request.get_data().decode()

        event = {"httpMethod": "POST",
                 "path": request.path,
                 "body": user_input}

        response: dict = lambda_handler(event=event, context=None)

        return send_response(response)


api.add_resource(Lambda, "/persistkey", "/encrypt",
                 "/decrypt", "/manage/info", "/manage/health", "/manage/keystatus")

if __name__ == "__main__":
    app.run(host="0.0.0.0", port="8080", threaded=True)
