import os
import json
from hsmcrypto.hsm_crypto_secret import HsmCryptoSecret
from hsmcrypto.hsm_crypto_db import HsmCryptoDb
from hsmcrypto.hsm_crypto_db_migrate import secret_2_db_migrate
from hsmcrypto.crypto_handler import Crypto
from hsmcrypto.manage_info import manage_info
from hsmcrypto.manage_health import manage_health
from hsmcrypto.manage_keystatus import KeyStatus

__all__ = ["lambda_handler"]

print("Initializing lambda_function")

hsm_crypto = None

key_status = None

HOST_SECRET = os.getenv("HOST_SECRET", "Unknown")

CRYPTO_SECRET = os.getenv("CRYPTO_SECRET", None)

KEYS_SECRET = os.getenv("KEYS_SECRET", None)

PYCRYPTO_DB = os.getenv("PYCRYPTO_DB", None)

SERVER_ENV = os.getenv("SERVER_ENV", "Unknown")

if PYCRYPTO_DB is not None:
    if CRYPTO_SECRET is not None and KEYS_SECRET is not None:
        secret_2_db_migrate(CRYPTO_SECRET, KEYS_SECRET, PYCRYPTO_DB)
    hsm_crypto = HsmCryptoDb(HOST_SECRET, PYCRYPTO_DB)
else:
    hsm_crypto = HsmCryptoSecret(HOST_SECRET, CRYPTO_SECRET, KEYS_SECRET)


def check_keys(body: dict, key_list: list[str]):
    for key in key_list:
        if key not in body:
            raise Exception(f"Missing key {key}")


def key_persist_response(body: dict):
    check_keys(body, ["cipherSuite", "dek", "kcv"])
    return hsm_crypto.encrypt_key(
        body["cipherSuite"],
        body["dek"],
        body.get("div"),
        body.get("dnonce"),
        body["kcv"],
        body.get("ivExplicitLen", 0))


def hsm_crypto_response(body: dict):
    check_keys(body, ["keyIdentifier"])

    crypto = Crypto(hsm_crypto.decrypt_key(body["keyIdentifier"]))

    if "plainDataList" in body:
        return crypto.batch_encrypt(body["plainDataList"])
    elif "plainData" in body:
        return crypto.encrypt(body["plainData"])
    elif "encDataList" in body:
        return crypto.batch_decrypt(body["encDataList"])
    elif "encData" in body:
        return crypto.decrypt(body["encData"])
    else:
        raise Exception("Missing data to encrypt or decrypt")


def lambda_handler(event, context):
    try:
        response: dict = None
        status_code = 200

        if event["httpMethod"] == "POST":
            body = json.loads(event["body"])
            if event["path"] == "/persistkey":
                response = key_persist_response(body)
            elif event["path"] in ["/encrypt", "/decrypt"]:
                response = hsm_crypto_response(body)
        elif event["path"] == "/manage/info":
            response = manage_info(SERVER_ENV)
        elif event["path"] == "/manage/health":
            response, status_code = manage_health(hsm_crypto)
        elif event["path"] == "/manage/keystatus":
            global key_status
            if key_status is None:
                key_status = KeyStatus(
                    HOST_SECRET, CRYPTO_SECRET, KEYS_SECRET, PYCRYPTO_DB)
            response = key_status.get_info()

        if response is not None and isinstance(response, dict):
            return {"statusCode": status_code, "headers": {"Content-Type": "application/json"}, "body": json.dumps(response)}

        raise Exception("Unsupported method or parameter")
    except Exception as e:
        return {"statusCode": 400, "headers": {"Content-Type": "text/plain"}, "body": e.args[0]}
