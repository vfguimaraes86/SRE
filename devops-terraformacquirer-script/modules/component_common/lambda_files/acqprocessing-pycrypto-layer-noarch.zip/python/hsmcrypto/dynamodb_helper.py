import boto3
import os
import json
from typing import Dict, Any, Tuple
from datetime import datetime
from botocore.client import BaseClient
from botocore.exceptions import ClientError

__all__ = ["DynamoDbHelper"]

AWS_PROFILE: str = os.getenv("AWS_PROFILE")
AWS_REGION: str = os.getenv("AWS_REGION")

dynamodb: BaseClient = boto3.Session(
    profile_name=AWS_PROFILE,
    region_name=AWS_REGION).client("dynamodb")


class DynamoDbHelper:
    def __init__(self, table_name: str, part_id: str) -> None:
        self.table: str = table_name
        self.part_id: str = part_id

    @staticmethod
    def __generate_id() -> str:
        dt: datetime = datetime.now()
        return dt.strftime("%y%m%d%H%M%S-%f")[:16]

    def get_data(self, id: str) -> str:
        key: Dict[str, Any] = {"part_id": {"S": self.part_id}, "id": {"S": id}}

        response: Dict[str, Any] = dynamodb.get_item(
            TableName=self.table, Key=key)

        if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
            data = response["Item"]["data"]["S"]

            try:
                return json.loads(data)
            except json.JSONDecodeError:
                return data

        raise Exception("get_data: Unable to get data")

    def get_data_last(self) -> Tuple[str, Any]:
        response: Dict[str, Any] = dynamodb.query(
            TableName=self.table,
            Limit=1,
            ScanIndexForward=False,
            ExpressionAttributeValues={":part_id": {"S": self.part_id}},
            KeyConditionExpression="part_id = :part_id"
        )

        if response["ResponseMetadata"]["HTTPStatusCode"] == 200 and len(response["Items"]) > 0:
            data: str = response["Items"][0]["data"]["S"]

            try:
                data = json.loads(data)
            except json.JSONDecodeError:
                pass

            return response["Items"][0]["id"]["S"], data

        raise Exception("get_data_last: Unable to get data")

    def update_data(self, data: str, id: str = None) -> str:
        try:
            register: Dict[str, Any] = {
                "part_id": {"S": self.part_id},
                "id": {"S": id if id is not None else DynamoDbHelper.__generate_id()},
                "data": {"S": data}
            }

            response: Dict[str, Any] = dynamodb.put_item(
                TableName=self.table,
                Item=register,
                ConditionExpression="attribute_not_exists(id)"
            )

            if response["ResponseMetadata"]["HTTPStatusCode"] == 200:
                return register["id"]["S"]
            else:
                raise Exception(
                    f"Unable to insert data with cause: {response}")
        except ClientError as e:
            if e.response["Error"]["Code"] == "CheckFailedException":
                raise Exception(f"ClientError: {e.response}")
            else:
                raise e

    def health(self) -> Tuple[str, Any]:
        try:
            return "UP", self.get_data_last()[1]
        except Exception as e:
            return "DOWN", f"{e}"

    def status(self) -> Dict[str, str]:
        response = dynamodb.describe_table(TableName=self.table)["Table"]

        return {
            "DbName": response["TableName"],
            "TableSizeBytes": response["TableSizeBytes"],
            "ItemCount": response["ItemCount"]
        }
