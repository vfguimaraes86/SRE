import os
from datetime import datetime

VERSION = "1.2"

APP_NAME = "acqprocessing-pycrypto-layer-noarch"

START_TIME = datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def manage_info(server_env: str) -> dict:
    return {
        "description": "Batch encryption using Neo to protect DEK key",
        "environment": server_env,
        "version": VERSION,
        "name": APP_NAME,
        "start_date": START_TIME}
