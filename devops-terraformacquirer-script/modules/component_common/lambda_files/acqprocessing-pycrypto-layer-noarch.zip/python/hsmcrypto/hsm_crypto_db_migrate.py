from hsmcrypto.secret_helper import SecretHelper
from hsmcrypto.dynamodb_helper import DynamoDbHelper

__all__ = ["secret_2_db_migrate"]


def save_db(table: DynamoDbHelper, secret_stage: str, secret_data: dict):
    for key in secret_data.keys():
        data: str = secret_data[key]
        id: str = f"{secret_stage}-{key}"

        print(f"Saving {id} to {table.table}/{table.part_id}...")

        if not data.startswith("{") and not data.endswith("}"):
            data_parts = data.split(";")
            data = f"{'-'.join(data_parts[:2])};{';'.join(data_parts[2:])}"

        table.update_data(data, id)


def migrate(secret_name: str, pycrypto_db_name: str, table_name: str):
    table = DynamoDbHelper(pycrypto_db_name, table_name)

    try:
        table.get_data_last()
        print(f"Already migrated {secret_name}!")
        return
    except Exception as e:
        print(f"{e}")
        pass

    print(f"Migrating {secret_name}...")
    secret = SecretHelper(secret_name)
    versions = secret.get_versions()
    secret_stages: dict = {}

    for version in versions:
        stage = SecretHelper.get_stage_name(version["VersionStages"])
        if stage is not None:
            secret.get_secret(stage)
            secret_stages[stage] = secret.data

    for secret_stage in sorted(secret_stages.keys()):
        save_db(table, secret_stage, secret_stages[secret_stage])


def secret_2_db_migrate(crypto_secret_name: str, keys_secret_name: str, pycrypto_db_name: str):
    migrate(crypto_secret_name, pycrypto_db_name, "crypto")
    migrate(keys_secret_name, pycrypto_db_name, "keys-vault")
