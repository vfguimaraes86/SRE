import os
import json
from typing import Union, Dict, Any
from hsmcrypto.secret_helper import SecretHelper

__all__ = ["SecretHandler"]


class SecretHandler(SecretHelper):

    def __init__(self, name: str, stage: str = "AWSCURRENT", init_stage: bool = False) -> None:
        super().__init__(name, stage, SecretHandler.__get_secret_size())

        if self.stage is None and init_stage:
            super().init_stage()

    @staticmethod
    def __get_secret_size() -> int:
        try:
            return int(os.getenv("SECRET_SIZE", "0"))
        except Exception as e:
            return 0

    def get_data_entry(self, key: str) -> Union[str, dict]:
        try:
            return json.loads(self.data[key])
        except Exception as e:
            return self.data[key]

    def get_last_data_entry(self) -> str or None:
        if self.data is not None and self.last_key is not None:
            return self.get_data_entry(self.last_key)
        else:
            return None

    def health(self):
        try:
            return "UP", self.get_data_entry(self.last_key)
        except Exception as e:
            return "DOWN", f"{e}"

    def status(self) -> Dict[str, Any]:
        status: dict = {"SecretName": self.name, "VersionStages": {}}
        versions: list = super().get_versions()

        for version in versions:
            version_info = {}
            version_stages = version["VersionStages"]
            version_stage = version["VersionStages"][0]

            if len(version_stages) > 1:
                for v in version_stages:
                    if "AWS" not in v:
                        version_stage = v
                        break

            super().get_secret(version_stage)
            version_info["VersionId"] = version["VersionId"]
            version_info["keys"] = len(self.data)
            version_info["size"] = self.data_size
            status["VersionStages"][version_stage] = version_info

        return status
