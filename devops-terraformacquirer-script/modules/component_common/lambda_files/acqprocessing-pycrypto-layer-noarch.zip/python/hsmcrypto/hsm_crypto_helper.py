from base64 import b64decode
from threading import RLock
from typing import Dict, Tuple

from hsmcrypto.secret_handler import SecretHandler
from hsmcrypto.neo import neo_encrypt_key, neo_decrypt_key
from hsmcrypto.crypto_handler import KeyData, is_valid_key, is_valid_key_b64

__all__ = ["HsmCryptoHelper"]


class HsmCryptoHelper:
    KEY_PARTS_WITH_NONCE_LEN = 5
    KEY_PARTS_WITH_IV_EXPLICIT_LEN = 6

    def __init__(self, host_secret_name: str):
        self.cache_lock: RLock = RLock()
        self.host_secret_name = host_secret_name
        self.key_data_dict: Dict[str, KeyData] = {}

    def get_key_parts(self, key_parts: list) -> Tuple[str, str, str, str, str, int]:
        key_parts_offset: int = 0
        key_parts_len: int = len(key_parts)
        cipher_suite: str = key_parts[key_parts_offset]
        key_parts_offset += 1
        b64_edek: str = key_parts[key_parts_offset]
        key_parts_offset += 1
        b64_ediv: str = key_parts[key_parts_offset]
        key_parts_offset += 1
        b64_enonce: str = None
        b64_kcv: str = None
        iv_explicit_len: int = 0

        if key_parts_len < HsmCryptoHelper.KEY_PARTS_WITH_NONCE_LEN:
            b64_kcv = key_parts[key_parts_offset]
        else:
            b64_enonce = key_parts[key_parts_offset]
            key_parts_offset += 1
            b64_kcv = key_parts[key_parts_offset]

        if key_parts_len >= HsmCryptoHelper.KEY_PARTS_WITH_IV_EXPLICIT_LEN:
            key_parts_offset += 1
            iv_explicit_len = int(key_parts[key_parts_offset])

        return cipher_suite, b64_edek, b64_ediv, b64_enonce, b64_kcv, iv_explicit_len

    def get_cache(self, key_identifier: str) -> KeyData:
        try:
            self.cache_lock.acquire()
            return self.key_data_dict.get(key_identifier)
        finally:
            self.cache_lock.release()

    def update_cache(self, key_identifier: str, key_data: KeyData) -> None:
        self.cache_lock.acquire()
        self.key_data_dict[key_identifier] = key_data
        self.cache_lock.release()

    def encrypt_key(self, crypto_cfg: dict, cipher_suite: str, b64_dek: str, b64_div: str, b64_dnonce: str, b64_kcv: str, iv_explicit_len: int) -> Tuple[KeyData, str]:
        if is_valid_key_b64(cipher_suite, b64_dek, b64_div, b64_dnonce, b64_kcv, iv_explicit_len):
            b64_edek, b64_ediv, b64_enonce = neo_encrypt_key(
                SecretHandler(self.host_secret_name).get_last_data_entry(),
                crypto_cfg,
                b64_dek,
                b64_div,
                b64_dnonce)
            key_data = KeyData.from_b64(
                cipher_suite, b64_dek, b64_div, b64_dnonce, iv_explicit_len)

            return key_data, f"{cipher_suite};{b64_edek};{b64_ediv};{b64_enonce};{b64_kcv};{iv_explicit_len}"
        else:
            raise Exception("encrypt_key: Invalid KCV")

    def decrypt_key(self, crypto_cfg: dict, key_parts: list) -> KeyData:
        cipher_suite, b64_edek, b64_ediv, b64_enonce, b64_kcv, iv_explicit_len = self.get_key_parts(
            key_parts)

        dek, div, dnonce = neo_decrypt_key(
            SecretHandler(self.host_secret_name).get_last_data_entry(),
            crypto_cfg,
            b64_edek,
            b64_ediv,
            b64_enonce
        )

        if is_valid_key(cipher_suite, dek, div, dnonce, b64decode(b64_kcv), iv_explicit_len):
            return KeyData(cipher_suite, dek, div, dnonce, iv_explicit_len)
        else:
            raise Exception("decrypt_key: Invalid KCV")
