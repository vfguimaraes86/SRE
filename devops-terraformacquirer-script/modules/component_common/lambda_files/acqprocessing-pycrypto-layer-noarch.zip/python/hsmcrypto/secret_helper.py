import boto3
import os
import json
from datetime import datetime
from botocore.client import BaseClient
from botocore.exceptions import ClientError

__all__ = ["SecretHelper"]

AWS_PROFILE: str = os.getenv("AWS_PROFILE")
AWS_REGION: str = os.getenv("AWS_REGION")

secret_client: BaseClient = boto3.Session(
    profile_name=AWS_PROFILE,
    region_name=AWS_REGION).client("secretsmanager")


class SecretHelper:
    DEFAULT_MARGIN: int = 1024
    SECRET_SZ_MIN: int = 2048
    SECRET_SZ_MAX: int = 65536
    AWS_STAGES: list = ["AWSPREVIOUS", "AWSCURRENT"]

    def __init__(self, name: str, stage: str = "AWSCURRENT", secret_sz: int = SECRET_SZ_MAX) -> None:
        self.secret_sz = SecretHelper.__init_size(secret_sz)
        self.name: str = name
        self.id: str = None
        self.stage: str = None
        self.data: dict = {}
        self.data_size: int = 0
        self.last_key: str = None

        try:
            self.get_secret(stage)
        except ClientError as e:
            error: dict = e.response["Error"]
            if "ResourceNotFoundException" in error["Code"]:
                pass
            else:
                raise e

    @staticmethod
    def __generate_stage() -> str:
        dt: datetime = datetime.now()
        return dt.strftime("%y%m%d%H%M%S")

    @staticmethod
    def __init_size(secret_sz: int) -> int:
        if secret_sz <= 0 or secret_sz > SecretHelper.SECRET_SZ_MAX:
            secret_sz = SecretHelper.SECRET_SZ_MAX
        elif secret_sz < SecretHelper.SECRET_SZ_MIN:
            secret_sz = SecretHelper.SECRET_SZ_MIN

        return secret_sz

    @staticmethod
    def __get_stage_name(version_stages: list) -> str:
        return next((v for v in version_stages if v not in SecretHelper.AWS_STAGES), None)

    def __init_helper(self, secret: dict) -> None:
        self.id = secret["VersionId"]
        self.stage = SecretHelper.__get_stage_name(secret["VersionStages"])
        if "SecretString" in secret:
            self.data = json.loads(secret["SecretString"])
            self.data_size = len(secret["SecretString"])
            self.last_key = max(self.data.keys())

    def __secret_message(self, stage: str, previous_id: str = None) -> str:
        if previous_id is not None:
            return f"secret {self.name} stage {stage} in VersionId {previous_id} -> {self.id}"
        else:
            return f"secret {self.name} stage {stage} in VersionId {self.id}"

    def __update_stage_unsafe(self, stage: str, previous_id: str = None) -> None:
        if previous_id is not None:
            result = secret_client.update_secret_version_stage(SecretId=self.name, VersionStage=stage,
                                                               RemoveFromVersionId=previous_id, MoveToVersionId=self.id)
        else:
            result = secret_client.update_secret_version_stage(
                SecretId=self.name, VersionStage=stage, MoveToVersionId=self.id)

        print(f"Updated {self.__secret_message(stage, previous_id)}")

    def __add_new_stage(self) -> bool:
        if self.stage is None:
            return True
        else:
            expected_size = self.data_size + SecretHelper.DEFAULT_MARGIN
            if expected_size > self.secret_sz:
                print(
                    f"The expected new secret size is {expected_size} exceeds {self.secret_sz} current entries: {len(self.data.keys())}")
                return True

        return False

    def __update_stage(self, stage: str, previous_id: str = None) -> None:
        try:
            self.__update_stage_unsafe(stage, previous_id)
        except ClientError as e:
            error: dict = e.response["Error"]
            if "LimitExceededException" in error["Code"]:
                self.__rotate_stage(stage)
            else:
                raise e

        self.get_secret(stage)

    def __put_secret(self) -> None:
        secret = secret_client.put_secret_value(
            SecretId=self.name, SecretString=json.dumps(self.data))
        self.__init_helper(secret)

    def __update_data_unsafe(self, data: str) -> str:
        stage = self.stage
        previous_id = self.id
        keys_data_key: str = None

        if self.__add_new_stage():
            stage = SecretHelper.__generate_stage()
            previous_id = None
            self.data = {}
            self.last_key = "000"

        try:
            keys_data_key = f"{int(self.last_key) + 1:03}"
        except Exception as e:
            keys_data_key = "001"

        self.data[keys_data_key] = data

        self.__put_secret()
        self.__update_stage(stage, previous_id)

        return f"{self.stage}-{keys_data_key}"

    def __rotate_stage(self, stage: str):
        delete_version: dict = None

        versions = self.get_versions()

        for version in versions:
            if SecretHelper.__get_stage_name(version["VersionStages"]) is None:
                continue
            elif delete_version is None or version["CreatedDate"].timestamp() < delete_version["CreatedDate"].timestamp():
                delete_version = version

        if delete_version is not None:
            print(
                f"Deleting from secret {self.name} stage {delete_version['VersionStages']} from VersionId {delete_version['VersionId']}")

            result = secret_client.update_secret_version_stage(SecretId=self.name,
                                                               VersionStage=delete_version["VersionStages"][0],
                                                               RemoveFromVersionId=delete_version["VersionId"])
            self.__update_stage_unsafe(stage)
        else:
            raise Exception("Unable rotate to VersionStage {stage}")

    def __get_secret_value(self, stage: str) -> None:
        return secret_client.get_secret_value(SecretId=self.name, VersionStage=stage)

    def init_stage(self):
        self.__update_stage(SecretHelper.__generate_stage())

    def get_versions(self):
        return secret_client.list_secret_version_ids(SecretId=self.name, MaxResults=100)["Versions"]

    def get_secret(self, stage: str = "AWSCURRENT") -> None:
        secret = self.__get_secret_value(stage)
        self.__init_helper(secret)

    def update_data(self, data: str) -> str:
        try:
            return self.__update_data_unsafe(data)
        except ClientError as e:
            error: dict = e.response["Error"]
            if "ValidationException" in error["Code"]:
                print(f"Warning: {self.__secret_message(self.stage)} is full")
                self.stage = None
                return self.__update_data_unsafe(data)
            else:
                raise e
