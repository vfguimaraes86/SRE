from typing import Dict
from hsmcrypto.hsm_crypto_helper import HsmCryptoHelper
from hsmcrypto.dynamodb_helper import DynamoDbHelper
from hsmcrypto.crypto_handler import KeyData

__all__ = ["HsmCryptoDb"]


class HsmCryptoDb(HsmCryptoHelper):
    KEY_PARTS_OFFSET = 1

    def __init__(self, host_secret_name: str, pycrypto_db_name: str):
        super().__init__(host_secret_name)
        self.crypto = DynamoDbHelper(pycrypto_db_name, "crypto")
        self.keys = DynamoDbHelper(pycrypto_db_name, "keys-vault")

    def encrypt_key(self, cipher_suite: str, b64_dek: str, b64_div: str, b64_dnonce: str, b64_kcv: str, iv_explicit_len: int) -> Dict[str, str]:
        crypto_indentifier, crypto_cfg = self.crypto.get_data_last()
        key_data, data = super().encrypt_key(
            crypto_cfg,
            cipher_suite,
            b64_dek,
            b64_div,
            b64_dnonce,
            b64_kcv,
            iv_explicit_len
        )
        key_identifier = self.keys.update_data(f"{crypto_indentifier};{data}")
        super().update_cache(key_identifier, key_data)
        return {"keyIdentifier": key_identifier}

    def decrypt_key(self, key_identifier: str) -> KeyData:
        key_data = super().get_cache(key_identifier)

        if key_data is None:
            key_parts = self.keys.get_data(key_identifier).split(";")

            crypto_cfg = self.crypto.get_data(key_parts[0])

            key_data = super().decrypt_key(
                crypto_cfg, key_parts[HsmCryptoDb.KEY_PARTS_OFFSET:])

            super().update_cache(key_identifier, key_data)

        return key_data
