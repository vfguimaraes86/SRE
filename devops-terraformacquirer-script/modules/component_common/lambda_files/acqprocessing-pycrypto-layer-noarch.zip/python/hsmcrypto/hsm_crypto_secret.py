from threading import RLock
from typing import Dict
from hsmcrypto.hsm_crypto_helper import HsmCryptoHelper
from hsmcrypto.secret_handler import SecretHandler
from hsmcrypto.crypto_handler import KeyData

__all__ = ["HsmCryptoSecret"]


class HsmCryptoSecret(HsmCryptoHelper):
    KEY_PARTS_OFFSET = 2

    def __init__(self, host_secret_name: str, crypto_secret_name: str, keys_secret_name: str):
        super().__init__(host_secret_name)
        self.secret_lock: RLock = RLock()
        self.crypto_secret_name: str = crypto_secret_name
        self.keys_secret_name: str = keys_secret_name

    def __get_secret_safe(self, stage: str = None, key: str = None):
        try:
            self.secret_lock.acquire()
            if stage is None and key is None:
                keys = SecretHandler(self.keys_secret_name)
                crypto = SecretHandler(
                    self.crypto_secret_name, init_stage=True)
            else:
                keys = SecretHandler(self.keys_secret_name, stage)
                crypto_stage = keys.get_data_entry(key).split(";")[0]
                crypto = SecretHandler(self.crypto_secret_name, crypto_stage)
            return keys, crypto
        finally:
            self.secret_lock.release()

    def __update_secret_safe(self, secret: SecretHandler,  data: str) -> str:
        try:
            self.secret_lock.acquire()
            return secret.update_data(data)
        finally:
            self.secret_lock.release()

    def encrypt_key(self, cipher_suite: str, b64_dek: str, b64_div: str, b64_dnonce: str, b64_kcv: str, iv_explicit_len: int) -> Dict[str, str]:
        keys, crypto = self.__get_secret_safe()
        crypto_cfg = crypto.get_last_data_entry()
        key_data, data = super().encrypt_key(
            crypto_cfg,
            cipher_suite,
            b64_dek,
            b64_div,
            b64_dnonce,
            b64_kcv,
            iv_explicit_len
        )
        key_identifier = self.__update_secret_safe(
            keys, f"{crypto.stage};{crypto.last_key};{data}")
        super().update_cache(key_identifier, key_data)
        return {"keyIdentifier": key_identifier}

    def decrypt_key(self, key_identifier: str) -> KeyData:
        key_data = super().get_cache(key_identifier)

        if key_data is None:
            id_parts = key_identifier.split("-")
            keys, crypto = self.__get_secret_safe(id_parts[0], id_parts[1])
            key_parts = keys.get_data_entry(id_parts[1]).split(";")
            crypto_cfg = crypto.get_data_entry(key_parts[1])

            key_data = super().decrypt_key(
                crypto_cfg, key_parts[HsmCryptoSecret.KEY_PARTS_OFFSET:])

            super().update_cache(key_identifier, key_data)

        return key_data
