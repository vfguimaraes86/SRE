import json
import requests
import binascii
from base64 import b64encode, b64decode
from typing import Dict, Any


def configure(cfg: Dict[str, str], request: Dict[str, str], cfg_key: str, request_key: str, default_value: str = None) -> None:
    cfg_value = cfg.get(cfg_key)

    if cfg_value is None or 0 == len(cfg_value) and default_value is not None:
        cfg_value = default_value

    if cfg_value is not None and len(cfg_value) > 0:
        request[request_key] = cfg_value


def make_request(cfg: Dict[str, str], request_data: str, data: str) -> Dict[str, Any]:
    request = {request_data: data}

    configure(cfg, request, "keyIndex", "indiceKey")
    configure(cfg, request, "keyType", "keyType", "ZEK")
    configure(cfg, request, "keyIv", "iv")
    configure(cfg, request, "keyKsn", "ksn")
    configure(cfg, request, "operationMode", "operationMode", "ECB")

    return request


def do_request(host_cfg: Dict[str, str], endpoint_key: str, request: Dict[str, Any], response_key: str) -> str:
    headers = {"Content-type": "application/json",
               "token": host_cfg["token"]}

    response = requests.post(host_cfg[endpoint_key], headers=headers,
                             data=json.dumps(request))

    json_response = json.loads(response.content.decode())

    if response.status_code == 200:
        return json_response[response_key]
    else:
        raise Exception(json_response)


def encrypt(host_cfg: dict, crypto_cfg: dict, b64_data: str) -> str:
    if b64_data:
        plain_data = binascii.hexlify(b64decode(b64_data)).decode()
        request = make_request(crypto_cfg, "contentToEncrypt", plain_data)
        response = do_request(host_cfg, "encryptEndpoint",
                              request, "encryptedContent")
        data_enc = binascii.unhexlify(response)
        return b64encode(data_enc).decode()

    return ""


def decrypt(host_cfg: dict, crypto_cfg: dict, b64_data: str) -> bytes:
    if b64_data:
        cipher_data = binascii.hexlify(b64decode(b64_data)).decode()
        request = make_request(
            crypto_cfg, "encryptedContent", cipher_data.upper())
        response = do_request(host_cfg, "decryptEndpoint",
                              request, "cardNumber")
        return binascii.unhexlify(response)

    return ""


def neo_encrypt_key(host_cfg: dict, crypto_cfg: dict, b64_dek: str, b64_div: str = None, b64_dnonce: str = None) -> tuple[str, str]:
    edek = encrypt(host_cfg, crypto_cfg, b64_dek)
    ediv = encrypt(host_cfg, crypto_cfg, b64_div)
    enonce = encrypt(host_cfg, crypto_cfg, b64_dnonce)

    return edek, ediv, enonce


def neo_decrypt_key(host_cfg: dict, crypto_cfg: dict, b64_edek: str, b64_ediv: str = None, b64_enonce: str = None) -> tuple[bytes, bytes]:
    dek = decrypt(host_cfg, crypto_cfg, b64_edek)
    div = decrypt(host_cfg, crypto_cfg, b64_ediv)
    dnonce = decrypt(host_cfg, crypto_cfg, b64_enonce)

    return dek, div, dnonce
