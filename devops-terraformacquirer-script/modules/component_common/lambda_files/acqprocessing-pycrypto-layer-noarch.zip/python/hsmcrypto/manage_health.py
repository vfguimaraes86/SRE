import base64
from time import time
from hsmcrypto.secret_handler import SecretHandler
from hsmcrypto.hsm_crypto_secret import HsmCryptoSecret
from hsmcrypto.hsm_crypto_db import HsmCryptoDb
from hsmcrypto.neo import encrypt
from typing import Any, Dict, Tuple, Union


next_call: float = 0
health_response: Tuple[Dict[str, Any], int] = None
plain_data = base64.b64encode(b"secret").decode()


def hsm_crypto_response(host_details: Tuple[str, str], crypto_details: Tuple[str, str], keys_details: Tuple[str, str]) -> Dict[str, Any]:
    response: dict = {"status": "DOWN", "details": "UNAVAILABLE"}

    try:
        response["status"] = "DOWN",
        response["details"] = {
            "host": host_details[0],
            "crypto": crypto_details[0],
            "keys": keys_details[0],
            "neo": "DOWN"
        }

        ciphered_data = encrypt(host_details[1], crypto_details[1], plain_data)

        if ciphered_data is not None:
            response["status"] = "UP"
            response["details"]["neo"] = "UP"
    except Exception as e:
        response["details"] = f"{e}"

    return response


def manage_health_internal(hsm_crypto: Union[HsmCryptoSecret, HsmCryptoDb]) -> Tuple[Dict[str, Any], int]:
    hsm_crypto_status: Dict[str, Any] = None

    host_details = SecretHandler(hsm_crypto.host_secret_name).health()

    if isinstance(hsm_crypto, HsmCryptoSecret):
        crypto_details = SecretHandler(hsm_crypto.crypto_secret_name).health()
        keys_details = SecretHandler(hsm_crypto.keys_secret_name).health()
    elif isinstance(hsm_crypto, HsmCryptoDb):
        crypto_details = hsm_crypto.crypto.health()
        keys_details = hsm_crypto.keys.health()
    else:
        raise TypeError(
            "Invalid input type. Supported types are HsmCryptoSecret and HsmCryptoDb.")

    hsm_crypto_status = hsm_crypto_response(
        host_details,
        crypto_details,
        keys_details
    )

    response: Dict[str, Any] = {
        "status": hsm_crypto_status["status"],
        "components": {
            "hsm_crypto": hsm_crypto_status
        }
    }

    return response, 200 if response["status"] == "UP" else 503


def manage_health(hsm_crypto: Union[HsmCryptoSecret, HsmCryptoDb]) -> Tuple[Dict[str, Any], int]:
    global next_call, health_response

    if next_call < time() or health_response is None or health_response[1] != 200:
        health_response = manage_health_internal(hsm_crypto)
        next_call = time() + 60

    return health_response
