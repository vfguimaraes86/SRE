from cryptography.hazmat.primitives.ciphers import Cipher, modes
from cryptography.hazmat.primitives.ciphers.algorithms import AES
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import padding
from hashlib import sha256
from os import urandom
from typing import Any

__all__ = ["CryptoAes"]


class CryptoAes:
    BLOCK_SIZE = AES.block_size//8
    NONCE_SIZE = 12
    AEAD_TAG_SIZE = 16
    KCV_SIZE = 4
    IV_EXPLICT_KNOWN_LEN = 4

    def __init_iv(self, iv: bytes):
        if self.__iv_explicit_len > 0:
            if self.__iv_explicit_len >= (CryptoAes.IV_EXPLICT_KNOWN_LEN * 2):
                self.__iv_explicit_known_len = CryptoAes.IV_EXPLICT_KNOWN_LEN

            if iv is not None:
                # Fixed + random parts
                self.__iv_implicit = iv
            else:
                # Random part only
                self.__iv_implicit = b""
        else:
            # Fixed part only
            self.__iv_implicit = iv

        self.__iv_implicit_len = len(self.__iv_implicit)
        self.__iv = bytearray(self.__iv_implicit_len + self.__iv_explicit_len)
        self.__iv[0:self.__iv_implicit_len] = self.__iv_implicit

    def __init__(self, cipherSuite: str, dek: bytes, div: bytes = None, dnonce: bytes = None, iv_explicit_len: int = 0):
        self.__cipher: Cipher = None
        self.__aes_mode = None
        self.__padding = None
        self.__encrypt_function = None
        self.__decrypt_function = None
        self.__iv: bytearray
        self.__iv_implicit: bytes = None
        self.__iv_implicit_len: int = 0
        self.__iv_explicit_len: int = iv_explicit_len
        self.__iv_explicit_known_len: int = 0

        aes_mode, aes_padding = cipherSuite.split("/")[1:3]

        AES_MODE_MAPPING: dict[str, Any] = {"CBC": {"function": modes.CBC, "iv_len": CryptoAes.BLOCK_SIZE},
                                            "CFB": {"function": modes.CFB, "iv_len": CryptoAes.BLOCK_SIZE},
                                            "CFB8": {"function": modes.CFB8, "iv_len": CryptoAes.BLOCK_SIZE},
                                            "CTR": {"function": modes.CTR, "iv_len": CryptoAes.BLOCK_SIZE},
                                            "OFB": {"function": modes.OFB, "iv_len": CryptoAes.BLOCK_SIZE},
                                            "GCM": {"function": modes.GCM, "iv_len": CryptoAes.NONCE_SIZE}}

        AES_PADDING_MAPPING: dict[str, str] = {"PKCS5Padding": padding.PKCS7}

        aes_mode = AES_MODE_MAPPING.get(aes_mode)

        if aes_mode is not None:
            aes_mode_function = aes_mode["function"]
            iv_len: int = aes_mode["iv_len"]

            if aes_mode_function is modes.GCM:
                self.__encrypt_function = self.__encrypt_and_digest
                self.__decrypt_function = self.__decrypt_and_verify
                self.__init_iv(dnonce)
            elif aes_mode_function is not None:
                self.__encrypt_function = self.__encrypt
                self.__decrypt_function = self.__decrypt
                self.__init_iv(div)

            self.__aes_mode = aes_mode_function(urandom(iv_len))
        else:
            raise Exception("Invalid AES mode")

        self.__cipher = Cipher(AES(dek), self.__aes_mode,
                               backend=default_backend())

        padding_function = AES_PADDING_MAPPING.get(aes_padding)

        if padding_function:
            self.__padding = padding_function(AES.block_size)

    def __copy_to_iv_explicit(self, iv_explicit: bytes):
        self.__iv[self.__iv_implicit_len:self.__iv_implicit_len +
                  len(iv_explicit)] = iv_explicit

    def __update_vector(self, iv_explicit_known: bytes = None, iv_explicit_fixed: bytes = None) -> bytes:
        if iv_explicit_fixed:
            self.__copy_to_iv_explicit(iv_explicit_fixed)
        else:
            if self.__iv_explicit_len > 0:
                self.__copy_to_iv_explicit(urandom(self.__iv_explicit_len))

            if self.__iv_explicit_known_len > 0 and iv_explicit_known is not None:
                self.__copy_to_iv_explicit(
                    sha256(bytes(self.__iv[:4]) + iv_explicit_known).digest()[:4])

        self.__aes_mode._initialization_vector = bytes(self.__iv)

        return self.__aes_mode._initialization_vector[self.__iv_implicit_len:]

    def __encrypt(self, plain_data: bytes) -> bytes:
        encryptor = self.__cipher.encryptor()
        return encryptor.update(plain_data) + encryptor.finalize()

    def __decrypt(self, enc_data: bytes) -> bytes:
        decryptor = self.__cipher.decryptor()
        return decryptor.update(enc_data) + decryptor.finalize()

    def __encrypt_and_digest(self, plain_data: bytes) -> bytes:
        encryptor = self.__cipher.encryptor()
        ciphertext = encryptor.update(plain_data) + encryptor.finalize()
        return ciphertext + encryptor.tag

    def __decrypt_and_verify(self, enc_data: bytes) -> bytes:
        self.__aes_mode._tag = enc_data[-CryptoAes.AEAD_TAG_SIZE:]
        decryptor = self.__cipher.decryptor()
        return decryptor.update(enc_data[:-CryptoAes.AEAD_TAG_SIZE]) + decryptor.finalize()

    def encrypt(self, plain_data: bytes, iv_explicit_fixed: bytes = None) -> bytes:
        iv_explicit = self.__update_vector(plain_data, iv_explicit_fixed)

        if self.__padding:
            padder = self.__padding.padder()
            plain_data = padder.update(plain_data) + padder.finalize()

        return iv_explicit + self.__encrypt_function(plain_data)

    def decrypt(self, enc_data: bytes) -> bytes:
        self.__update_vector(
            iv_explicit_fixed=enc_data[:self.__iv_explicit_len])
        plain_data = self.__decrypt_function(enc_data[self.__iv_explicit_len:])

        if self.__padding:
            unpadder = self.__padding.unpadder()
            plain_data = unpadder.update(plain_data) + unpadder.finalize()

        return plain_data

    def check_kcv(self, kcv: bytes) -> bool:
        kcv_new = self.encrypt(bytes(CryptoAes.BLOCK_SIZE), kcv[:self.__iv_explicit_len])[
            :self.__iv_explicit_len + CryptoAes.KCV_SIZE]
        return kcv_new == kcv
