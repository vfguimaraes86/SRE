from base64 import b64encode, b64decode
from typing import List, Dict
from hsmcrypto.crypto_aes import CryptoAes

__all__ = ["KeyData", "Crypto", "is_valid_key", "is_valid_key_b64"]


def get_vector_value(b64_vector_value: str) -> bytes:
    if b64_vector_value is None or len(b64_vector_value) < 1:
        return None
    else:
        return b64decode(b64_vector_value)


def is_valid_key(cipher_suite: str, dek: bytes, div: bytes, dnonce: bytes, kcv: bytes, iv_explicit_len: int) -> bool:
    return CryptoAes(cipher_suite, dek, div, dnonce, iv_explicit_len).check_kcv(kcv)


def is_valid_key_b64(cipher_suite: str, b64_dek: str, b64_div: str, b64_dnonce: str, b64_kcv: str, iv_explicit_len: int) -> bool:
    return is_valid_key(cipher_suite,
                        b64decode(b64_dek),
                        get_vector_value(b64_div),
                        get_vector_value(b64_dnonce),
                        b64decode(b64_kcv),
                        iv_explicit_len)


class KeyData:
    def __init__(self, cipher_suite: str, dek: bytes, div: bytes = None, dnonce: bytes = None, iv_explicit_len: int = 0):
        self.cipher_suite: str = cipher_suite
        self.dek: bytes = dek
        self.div: bytes = div
        self.dnonce: bytes = dnonce
        self.iv_explicit_len: int = iv_explicit_len

    @classmethod
    def from_b64(cls, cipher_suite: str, b64_dek: str, b64_div: str = None, b64_dnonce: str = None, iv_explicit_len: int = 0):
        return cls(
            cipher_suite,
            b64decode(b64_dek),
            get_vector_value(b64_div),
            get_vector_value(b64_dnonce),
            iv_explicit_len
        )


class Crypto:
    def __init__(self, key_data: KeyData):
        self.cipher = CryptoAes(key_data.cipher_suite,
                                key_data.dek,
                                key_data.div,
                                key_data.dnonce,
                                key_data.iv_explicit_len)

    def encrypt_b64(self, b64_plain_data: str) -> str:
        try:
            plain_data: bytes = b64decode(b64_plain_data)
            cipher_data: bytes = self.cipher.encrypt(plain_data)
            return b64encode(cipher_data).decode()
        except Exception as e:
            print(f"Error Encrypting data {e}")
            raise RuntimeError("Error encrypting data")

    def decrypt_b64(self, b64_enc_data: str) -> str:
        try:
            cipher_data: bytes = b64decode(b64_enc_data)
            plain_data: bytes = self.cipher.decrypt(cipher_data)
            return b64encode(plain_data).decode()
        except Exception as e:
            print(f"Error decrypting data {e}")
            raise RuntimeError("Error decrypting data")

    def encrypt(self, plain_data: str) -> Dict[str, str]:
        return {"encData": self.encrypt_b64(plain_data)}

    def decrypt(self, enc_data: str) -> Dict[str, str]:
        return {"plainData": self.decrypt_b64(enc_data)}

    def batch_encrypt(self, plain_data_list: List[str]) -> Dict[str, List[str]]:
        enc_data_list: List[str] = [self.encrypt_b64(
            plain_data) for plain_data in plain_data_list]
        return {"encDataList": enc_data_list}

    def batch_decrypt(self, enc_data_list: List[str]) -> Dict[str, List[str]]:
        plain_data_list: List[str] = [self.decrypt_b64(
            enc_data) for enc_data in enc_data_list]
        return {"plainDataList": plain_data_list}
