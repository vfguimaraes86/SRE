import time
from hsmcrypto.secret_handler import SecretHandler
from hsmcrypto.dynamodb_helper import DynamoDbHelper

___all__ = ["KeyStatus"]


class KeyStatus:
    MIN_INTERVAL = 60

    @staticmethod
    def __init__secret(secret_name: str) -> SecretHandler:
        return None if secret_name is None else SecretHandler(secret_name)

    @staticmethod
    def __init__dynamodb(db_name: str, part_id: str) -> DynamoDbHelper:
        return None if db_name is None else DynamoDbHelper(db_name, part_id)

    def __init__(self, host_secret_name: str, crypto_secret_name: str, keys_secret_name: str, pycrypto_db_name: str, interval: int = MIN_INTERVAL) -> None:
        self.host = SecretHandler(host_secret_name)
        self.crypto = KeyStatus.__init__secret(crypto_secret_name)
        self.keys = KeyStatus.__init__secret(keys_secret_name)
        self.crypto_db = KeyStatus.__init__dynamodb(pycrypto_db_name, "crypto")
        self.keys_db = KeyStatus.__init__dynamodb(
            pycrypto_db_name, "keys-vault")

        self.next_call: int = 0
        self.interval: int = max(interval, KeyStatus.MIN_INTERVAL)
        self.secret_status: dict = {}

    @staticmethod
    def __get_tick_secs(interval: int = 0):
        return int(time.perf_counter()) + interval

    def __get_key_status(self):
        if self.next_call < KeyStatus.__get_tick_secs():
            self.secret_status = {"host": self.host.status()}

            if self.crypto is not None:
                self.secret_status["crypto"] = self.crypto.status()

            if self.keys is not None:
                self.secret_status["keys"] = self.keys.status()

            if self.crypto_db is not None:
                self.secret_status["crypto_db"] = self.crypto_db.status()

            if self.keys_db is not None:
                self.secret_status["keys_db"] = self.keys_db.status()

            self.next_call = KeyStatus.__get_tick_secs(self.interval)

        return self.secret_status

    def get_info(self):
        return self.__get_key_status()
