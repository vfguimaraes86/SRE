const AWS = require('aws-sdk');

exports.handler = async (event, context) => {
  var nameSpace = process.env.IDENTIFIER;
  var accountId = process.env.ACCOUNTID;
  var region = process.env.REGION;
  const secretName = `arn:aws:secretsmanager:${region}:${accountId}:secret:rds-password-${nameSpace}`;

  const secretsManager = new AWS.SecretsManager({ region });

  try {
    // Obtenha a senha atual do AWS Secrets Manager
    const data = await secretsManager.getSecretValue({ SecretId: secretName }).promise();
    const secret = JSON.parse(data.SecretString);
    const currentPassword = secret.password;

    // Gere uma nova senha
    const newPassword = generateNewPassword();

    // Atualize a senha do RDS no AWS Secrets Manager
    await secretsManager.updateSecret({ SecretId: secretName, SecretString: JSON.stringify({ password: newPassword }) }).promise();

    // Atualize a senha do RDS
    const rds = new AWS.RDS({ region });
    await rds.modifyDBInstance({ DBInstanceIdentifier: nameSpace, MasterUserPassword: newPassword }).promise();

    console.log(`Senha do RDS atualizada com sucesso.`);

    return { message: 'Senha do RDS atualizada com sucesso.' };
  } catch (error) {
    console.error(`Erro ao atualizar a senha do RDS: ${error}`);
    throw error;
  }
};

function generateNewPassword() {
  // Gerar uma nova senha aleatória
  // Implemente sua própria lógica para gerar uma senha segura aqui
  return Math.random().toString(36).slice(2);
}

